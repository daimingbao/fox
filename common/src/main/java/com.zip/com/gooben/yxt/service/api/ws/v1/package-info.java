@javax.xml.bind.annotation.XmlSchema(namespace = "http://v1.ws.api.service.yxt.gooben.com/")
package com.gooben.yxt.service.api.ws.v1;
