package cn.service;

import cn.entity.User;

/*
 * @ Copyright (c) Create by JASON  Date:2018-02-10  All rights reserved.
 *
 * @ class description：操作用户
 *
 */
public interface UserService {
	//查找用户
	public boolean findUser(User user);


}


